var bouton_sign_in= function(){
	window.location.href = "s_inscrire.html";
}
var bouton=document.getElementById("sign_in")
bouton.addEventListener("click",bouton_sign_in)